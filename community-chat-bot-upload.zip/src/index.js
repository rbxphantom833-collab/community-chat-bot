require("dotenv").config();
const {
  Client, GatewayIntentBits, REST, Routes, SlashCommandBuilder,
  PermissionFlagsBits, EmbedBuilder
} = require("discord.js");

const token = process.env.DISCORD_TOKEN;
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers
  ]
});

const settings = new Map();
const contexts = new Map();
const cooldowns = new Map();

const commands = [
  new SlashCommandBuilder().setName("chatbot").setDescription("Manage chatbot")
    .addSubcommand(s => s.setName("status").setDescription("Show chatbot status"))
    .addSubcommand(s => s.setName("enable").setDescription("Enable chat replies"))
    .addSubcommand(s => s.setName("disable").setDescription("Disable chat replies"))
    .addSubcommand(s => s.setName("clear-context").setDescription("Clear this server's chat context"))
    .addSubcommand(s => s.setName("personality").setDescription("Set reply style")
      .addStringOption(o => o.setName("style").setDescription("Reply style").setRequired(true)
        .addChoices({name:"Mix",value:"mix"},{name:"Friendly",value:"friendly"},{name:"Funny",value:"funny"},{name:"Savage",value:"savage"})))
    .addSubcommand(s => s.setName("set-channel").setDescription("Set chat channel")
      .addChannelOption(o => o.setName("channel").setDescription("Channel for chatbot replies").setRequired(true)))
    .addSubcommand(s => s.setName("cooldown").setDescription("Set reply cooldown in seconds")
      .addIntegerOption(o => o.setName("seconds").setDescription("0 to 60").setMinValue(0).setMaxValue(60).setRequired(true)))
    .addSubcommand(s => s.setName("ignore-channel").setDescription("Ignore a channel")
      .addChannelOption(o => o.setName("channel").setDescription("Channel to ignore").setRequired(true)))
    .addSubcommand(s => s.setName("reset").setDescription("Reset chatbot settings")),
  new SlashCommandBuilder().setName("welcome").setDescription("Welcome settings")
    .addSubcommand(s => s.setName("setup").setDescription("Set welcome channel")
      .addChannelOption(o => o.setName("channel").setDescription("Welcome channel").setRequired(true)))
    .addSubcommand(s => s.setName("toggle").setDescription("Toggle welcome messages")
      .addBooleanOption(o => o.setName("enabled").setDescription("Enable?").setRequired(true))),
  new SlashCommandBuilder().setName("serverinfo").setDescription("Show server information"),
  new SlashCommandBuilder().setName("userinfo").setDescription("Show user information")
    .addUserOption(o => o.setName("user").setDescription("User to inspect")),
  new SlashCommandBuilder().setName("avatar").setDescription("Show a user's avatar")
    .addUserOption(o => o.setName("user").setDescription("User")),
  new SlashCommandBuilder().setName("ping").setDescription("Check bot latency"),
  new SlashCommandBuilder().setName("help").setDescription("Show bot commands")
].map(c => c.toJSON());

function cfg(guildId) {
  if (!settings.has(guildId)) settings.set(guildId, {
    enabled: true, style: "mix", channelId: null, cooldown: 4,
    ignored: new Set(), welcomeChannel: null, welcomeEnabled: false
  });
  return settings.get(guildId);
}
function replyFor(text, style) {
  const t = text.toLowerCase();
  if (/\b(hi|hello|hey|hlo)\b/.test(t)) return ["Hey! 👋 Kya haal hai?","Hello! What's up? 😄","Yo! Welcome back!"][Math.floor(Math.random()*3)];
  if (/\bhow are you\b/.test(t)) return "I'm doing great! Ready to chat 😎";
  if (/\b(bot|who are you)\b/.test(t)) return "I'm your community chatbot! Mention me anytime. 🤖";
  if (/\b(thank|thanks|ty)\b/.test(t)) return "Anytime! ❤️";
  if (/\b(bye|goodbye|gn)\b/.test(t)) return "See you soon! 👋";
  if (style === "funny") return "Bro, that's a whole conversation starter 😂 Tell me more!";
  if (style === "savage") return "Interesting take 💀 Explain your logic!";
  if (style === "friendly") return "That's interesting! Tell me a little more 😊";
  return ["Lmao 😂","Fair enough! 😎","Wait, tell me more 👀","I hear you! What's next? 🤝"][Math.floor(Math.random()*4)];
}

client.once("ready", async () => {
  console.log(`Logged in as ${client.user.tag}`);
  const rest = new REST({ version: "10" }).setToken(token);
  await rest.put(Routes.applicationCommands(client.user.id), { body: commands });
  console.log("Slash commands registered.");
});

client.on("guildMemberAdd", async member => {
  const s = cfg(member.guild.id);
  if (!s.welcomeEnabled || !s.welcomeChannel) return;
  const ch = member.guild.channels.cache.get(s.welcomeChannel);
  if (ch) ch.send(`Welcome ${member}! 🎉`);
});

client.on("messageCreate", async message => {
  if (!message.guild || message.author.bot) return;
  const s = cfg(message.guild.id);
  if (!s.enabled || s.ignored.has(message.channel.id)) return;
  if (s.channelId && s.channelId !== message.channel.id) return;
  const mentioned = message.mentions.has(client.user);
  if (!mentioned && !s.channelId) return;
  const key = `${message.guild.id}:${message.author.id}`;
  const now = Date.now();
  if (now - (cooldowns.get(key) || 0) < s.cooldown * 1000) return;
  cooldowns.set(key, now);
  const clean = message.content.replace(/<@!?\d+>/g, "").trim();
  await message.reply(replyFor(clean, s.style));
});

client.on("interactionCreate", async interaction => {
  if (!interaction.isChatInputCommand()) return;
  const guildId = interaction.guildId;
  if (!guildId) return interaction.reply({content:"Use this command in a server.",ephemeral:true});
  const s = cfg(guildId);
  const name = interaction.commandName;
  if (name === "chatbot") {
    const sub = interaction.options.getSubcommand();
    if (sub === "status") return interaction.reply(`Chatbot: **${s.enabled ? "Enabled" : "Disabled"}** | Style: **${s.style}** | Cooldown: **${s.cooldown}s**`);
    if (sub === "enable") s.enabled = true;
    if (sub === "disable") s.enabled = false;
    if (sub === "clear-context") contexts.delete(guildId);
    if (sub === "personality") s.style = interaction.options.getString("style");
    if (sub === "set-channel") s.channelId = interaction.options.getChannel("channel").id;
    if (sub === "cooldown") s.cooldown = interaction.options.getInteger("seconds");
    if (sub === "ignore-channel") s.ignored.add(interaction.options.getChannel("channel").id);
    if (sub === "reset") settings.delete(guildId);
    return interaction.reply({content:`Chatbot setting updated: **${sub}**.`,ephemeral:true});
  }
  if (name === "welcome") {
    const sub = interaction.options.getSubcommand();
    if (sub === "setup") s.welcomeChannel = interaction.options.getChannel("channel").id;
    if (sub === "toggle") s.welcomeEnabled = interaction.options.getBoolean("enabled");
    return interaction.reply({content:`Welcome setting updated: **${sub}**.`,ephemeral:true});
  }
  if (name === "ping") return interaction.reply(`Pong! ${client.ws.ping}ms`);
  if (name === "serverinfo") return interaction.reply(`**${interaction.guild.name}**\nMembers: ${interaction.guild.memberCount}\nCreated: <t:${Math.floor(interaction.guild.createdTimestamp/1000)}:D>`);
  if (name === "userinfo") {
    const user = interaction.options.getUser("user") || interaction.user;
    return interaction.reply({embeds:[new EmbedBuilder().setTitle(user.tag).setThumbnail(user.displayAvatarURL()).setDescription(`User ID: ${user.id}\nCreated: <t:${Math.floor(user.createdTimestamp/1000)}:R>`)]});
  }
  if (name === "avatar") {
    const user = interaction.options.getUser("user") || interaction.user;
    return interaction.reply(user.displayAvatarURL({size:1024}));
  }
  if (name === "help") return interaction.reply("**Commands:** `/chatbot`, `/welcome`, `/serverinfo`, `/userinfo`, `/avatar`, `/ping`, `/help`");
});

if (!token) {
  console.error("Missing DISCORD_TOKEN. Set it in .env or Railway Variables.");
  process.exit(1);
}
client.login(token);
